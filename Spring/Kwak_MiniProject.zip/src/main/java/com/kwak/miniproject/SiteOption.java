package com.kwak.miniproject;

public class SiteOption {
	private int snsMsgPerPage;
	
	public SiteOption() {
		// TODO Auto-generated constructor stub
	}

	public SiteOption(int snsMsgPerPage) {
		super();
		this.snsMsgPerPage = snsMsgPerPage;
	}

	public int getSnsMsgPerPage() {
		return snsMsgPerPage;
	}

	public void setSnsMsgPerPage(int snsMsgPerPage) {
		this.snsMsgPerPage = snsMsgPerPage;
	}
}
